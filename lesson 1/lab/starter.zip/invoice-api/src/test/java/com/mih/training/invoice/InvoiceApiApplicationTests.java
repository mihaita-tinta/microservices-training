package com.mih.training.invoice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvoiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
